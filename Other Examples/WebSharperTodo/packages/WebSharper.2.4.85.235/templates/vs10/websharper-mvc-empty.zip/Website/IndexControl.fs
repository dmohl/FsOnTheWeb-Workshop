﻿namespace $safeprojectname$

open IntelliFactory.WebSharper
open IntelliFactory.WebSharper.Html

type IndexControl() =
    inherit Web.Control()

    [<JavaScript>]
    override this.Body = upcast Div []
